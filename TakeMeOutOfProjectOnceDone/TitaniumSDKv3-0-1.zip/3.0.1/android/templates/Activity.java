package ${config['appid']};

import org.appcelerator.titanium.TiRootActivity;

public final class ${config['classname']}Activity extends TiRootActivity
{
}
