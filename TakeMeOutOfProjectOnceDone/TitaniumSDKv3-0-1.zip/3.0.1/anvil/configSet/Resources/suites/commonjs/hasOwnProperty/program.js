
exports.run = function(testRun, valueOf) {
	var hasOwnProperty = require('./hasOwnProperty');
	var toString = require('./toString');

	return testRun;
}