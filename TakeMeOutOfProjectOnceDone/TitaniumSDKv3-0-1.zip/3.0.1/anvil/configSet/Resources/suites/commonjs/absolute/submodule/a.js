exports.foo = function () {
    return require('commonjs/absolute/b');
};
