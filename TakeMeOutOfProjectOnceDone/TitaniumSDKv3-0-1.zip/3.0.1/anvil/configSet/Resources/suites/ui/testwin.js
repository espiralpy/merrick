var win = Ti.UI.currentWindow;
setTimeout(function(){win.close();},500);
