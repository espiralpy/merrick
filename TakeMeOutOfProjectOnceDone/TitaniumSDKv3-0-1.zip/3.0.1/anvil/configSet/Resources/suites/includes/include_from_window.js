Ti.UI.currentWindow.passed = true;
